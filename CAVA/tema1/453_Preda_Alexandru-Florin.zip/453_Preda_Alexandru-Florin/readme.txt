Librariile necesare rularii proiectului:


scipy==1.9.2
opencv_python==4.6.0.66
numpy==1.23.2

Pentru a rula proiectul trebuiesc rulate toate celulele iar rezultatul va fi introdus in fisierul txtbuilder.