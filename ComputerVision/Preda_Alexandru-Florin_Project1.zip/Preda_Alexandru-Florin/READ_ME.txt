required libraries:

numpy==1.26.4
opencv-contrib-python==4.9.0.80

To run the solution you need to run the full_test.py script
Inside the script you might need to modify two lines:

- line 271 -> path variable is the path to the folder where the test data is found
- line 347 + line 355 -> the path where the solution is saved

