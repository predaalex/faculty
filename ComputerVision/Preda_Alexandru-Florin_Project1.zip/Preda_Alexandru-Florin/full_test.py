import os
import cv2 as cv
import numpy as np

MAX_MATCHES = 3500
GOOD_MATCH_PERCENT = 0.9


def alignImages(im1, im2):
    # Convert images to grayscale
    im1Gray = cv.cvtColor(im1, cv.COLOR_BGR2GRAY)
    im2Gray = cv.cvtColor(im2, cv.COLOR_BGR2GRAY)

    # Detect AKAZE featyres and compute descriptors
    # akaze = cv.AKAZE_create()
    # keypoints1, descriptors1 = akaze.detectAndCompute(im1Gray, None)
    # keypoints2, descriptors2 = akaze.detectAndCompute(im2Gray, None)

    # Detect ORB features and compute descriptors.
    sift = cv.SIFT_create(nfeatures=MAX_MATCHES)
    keypoints1, descriptors1 = sift.detectAndCompute(im1Gray, None)
    keypoints2, descriptors2 = sift.detectAndCompute(im2Gray, None)

    # orb = cv.ORB_create(MAX_MATCHES)
    # keypoints1, descriptors1 = orb.detectAndCompute(im1Gray, None)
    # keypoints2, descriptors2 = orb.detectAndCompute(im2Gray, None)

    # Match features.
    # matcher = cv.DescriptorMatcher_create(cv.DESCRIPTOR_MATCHER_BRUTEFORCE_HAMMING)
    # matches = matcher.match(descriptors1, descriptors2, None)
    # matches = list(matches)

    bf = cv.BFMatcher(cv.NORM_L1, crossCheck=True)
    matches = bf.match(descriptors1, descriptors2)
    matches = list(matches)

    # Sort matches by score
    matches.sort(key=lambda x: x.distance, reverse=False)

    # Remove not so good matches
    numGoodMatches = int(len(matches) * GOOD_MATCH_PERCENT)
    matches = matches[:numGoodMatches]

    # Draw top matches
    # imMatches = cv.drawMatches(im1, keypoints1, im2, keypoints2, matches, None)
    # cv.imshow("matches", imMatches)
    # cv.imwrite("matches.jpg", imMatches)

    # Extract location of good matches
    points1 = np.zeros((len(matches), 2), dtype=np.float32)
    points2 = np.zeros((len(matches), 2), dtype=np.float32)

    for i, match in enumerate(matches):
        points1[i, :] = keypoints1[match.queryIdx].pt
        points2[i, :] = keypoints2[match.trainIdx].pt

    # print(f"points1 = {points1.shape}")
    # print(f"points2 = {points2.shape}")
    # print(points1)

    if len(points1) >= 4:
        # Find homography
        h, mask = cv.findHomography(points1, points2, cv.RANSAC)

        # Use homography
        height, width, channels = im2.shape
        im1Reg = cv.warpPerspective(im1, h, (width, height))

        return im1Reg, h
    else:
        print("no keypoints matching")
        return im1, 0


def filter_image(img):
    mask = cv.inRange(img, 0, 120)
    res = cv.bitwise_and(img, img, mask=mask)

    return res


def classify_patch(patch_img):
    patch_img = cv.cvtColor(patch_img, cv.COLOR_BGR2GRAY)
    # cv.imshow("gray_patch", patch)
    # cv.waitKey(0)

    probabilities = []
    for label, template_img in pieces_templates:
        result = cv.matchTemplate(patch_img, template_img, cv.TM_CCOEFF_NORMED)
        probability = np.max(result)
        probabilities.append((label, probability))

    # we try to search for pieces with 2 digits first because 1 digit template will be found in 2 digit templates
    # probabilities over score_threshold for pieces with 2 digits
    score_threshold = 0.8
    thresholded_scores = [p for p in probabilities if p[1] > score_threshold and p[0] >= 10]
    if len(thresholded_scores) != 0:
        thresholded_scores.sort(key=lambda x: x[1], reverse=True)
        return thresholded_scores[0]

    # else return best for 1 digit
    probabilities.sort(key=lambda x: x[1], reverse=True)
    return probabilities[0]


def get_lookup_table():
    look_up_table = [[1 for _ in range(14)] for _ in range(14)]

    ###### 3 ###########
    look_up_table[0][0] = 3
    look_up_table[0][6] = 3
    look_up_table[0][7] = 3
    look_up_table[0][13] = 3

    look_up_table[6][0] = 3
    look_up_table[7][0] = 3
    look_up_table[13][0] = 3

    look_up_table[13][6] = 3
    look_up_table[13][7] = 3
    look_up_table[13][13] = 3

    look_up_table[6][13] = 3
    look_up_table[7][13] = 3
    ###### 3 ###########

    ###### 2 ###########
    look_up_table[1][1] = 2
    look_up_table[2][2] = 2
    look_up_table[3][3] = 2
    look_up_table[4][4] = 2

    look_up_table[4][9] = 2
    look_up_table[3][10] = 2
    look_up_table[2][11] = 2
    look_up_table[1][12] = 2

    look_up_table[9][4] = 2
    look_up_table[10][3] = 2
    look_up_table[11][2] = 2
    look_up_table[12][1] = 2

    look_up_table[9][9] = 2
    look_up_table[10][10] = 2
    look_up_table[11][11] = 2
    look_up_table[12][12] = 2
    ###### 2 ###########

    ###### signs #######
    look_up_table[1][4] = "%"
    look_up_table[2][5] = "-"
    look_up_table[3][6] = "+"
    look_up_table[4][6] = '*'

    look_up_table[4][1] = "%"
    look_up_table[5][2] = "-"
    look_up_table[6][3] = "*"
    look_up_table[6][4] = "+"

    look_up_table[12][4] = "%"
    look_up_table[11][5] = "-"
    look_up_table[10][6] = "*"
    look_up_table[9][6] = '+'

    look_up_table[12][9] = "%"
    look_up_table[11][8] = "-"
    look_up_table[10][7] = "+"
    look_up_table[9][7] = "*"

    look_up_table[9][1] = "%"
    look_up_table[8][2] = "-"
    look_up_table[7][3] = "+"
    look_up_table[7][4] = "*"

    look_up_table[4][7] = "+"
    look_up_table[3][7] = "*"
    look_up_table[2][8] = "-"
    look_up_table[1][9] = "%"

    look_up_table[6][9] = "*"
    look_up_table[6][10] = "+"
    look_up_table[5][11] = "-"
    look_up_table[4][12] = "%"

    look_up_table[7][9] = "+"
    look_up_table[7][10] = "*"
    look_up_table[8][11] = "-"
    look_up_table[9][12] = "%"
    ###### signs #######

    return look_up_table


def get_score(board, i, j):
    directions = 0
    multiplier = 1
    if isinstance(lookup_table[i][j], int):
        multiplier = lookup_table[i][j]

    c = board[i][j]
    ### up
    if i - 2 >= 0:
        a = board[i - 1][j]
        b = board[i - 2][j]

        directions = check_calculus(a, b, c, directions, i, j)

    ## left
    if j - 2 >= 0:
        a = board[i][j - 1]
        b = board[i][j - 2]

        directions = check_calculus(a, b, c, directions, i, j)

    ## right
    if j + 2 <= 13:
        a = board[i][j + 1]
        b = board[i][j + 2]

        directions = check_calculus(a, b, c, directions, i, j)
    ## down
    if i + 2 <= 13:
        a = board[i + 1][j]
        b = board[i + 2][j]

        directions = check_calculus(a, b, c, directions, i, j)

    return board[i][j] * multiplier * directions


def check_calculus(a, b, c, directions, i, j):
    if a is not None and b is not None and a >= 0 and b >= 0:
        if isinstance(lookup_table[i][j], int):
            try:
                if a + b == c or abs(a - b) == c or a * b == c or a / b == c:
                    directions += 1
            except ZeroDivisionError as zeroError:
                print(zeroError)
        elif isinstance(lookup_table[i][j], str):
            sign = lookup_table[i][j]
            if sign == "+":
                if a + b == c:
                    directions += 1
            elif sign == "-":
                if abs(a - b) == c:
                    directions += 1
            elif sign == "*":
                if a * b == c:
                    directions += 1
            elif sign == "%":
                try:
                    if a / b == c or b / a == c:
                        directions += 1
                except ZeroDivisionError as zeroError:
                    print(zeroError)
    return directions


pieces_path = "./pieces_templates"
pieces_templates = [(int(template_path.split("_")[0]), cv.imread(f"{pieces_path}/{template_path}", cv.IMREAD_GRAYSCALE))
                    for template_path in os.listdir(f"{pieces_path}") if
                    template_path.endswith(".png") or template_path.endswith(".jpeg")]

board_template_path = "board_templates/board_template.png"  # imagine dupa care va fi aliniata imagine camerei
board_template = cv.imread(board_template_path, cv.IMREAD_COLOR)
board_template = cv.resize(board_template, None, fx=0.4, fy=0.4)

games_images = []
games_turns = []
games_scores = []
path = "./test"
files = sorted(os.listdir(path))
int_to_dict = {i: chr(64 + i) for i in range(1, 27)}
lookup_table = get_lookup_table()

game = []
counter = 1
for file in files:
    if file.endswith(".jpg") and file.startswith(f"{counter}_"):
        image = cv.imread(f"{path}/{file}", cv.IMREAD_COLOR)
        image = cv.resize(image, None, fx=0.4, fy=0.4)
        game.append(image)
    elif "turns" in file:
        games_images.append(game)
        game = []

        turns = open(f"{path}/{file}", 'r')
        content = turns.readlines()
        content.append("PlayerWhoCares 51")
        games_turns.append(content)
        counter += 1


for game_idx, (game_turns, game_images) in enumerate(zip(games_turns, games_images)):
    print(f"GAME {game_idx + 1}")

    board = [[None for _ in range(14)] for _ in range(14)]
    board = np.array(board)

    board[6][6] = 1
    board[6][7] = 2
    board[7][6] = 3
    board[7][7] = 4

    for turn1, turn2 in zip(game_turns, game_turns[1:]):
        points = 0
        a = int(turn1.split()[1]) - 1
        b = int(turn2.split()[1]) - 1
        print(f"{turn1.split()[0]} {a + 1} - {b + 1}")
        player_turn_images = game_images[a:b]

        for idx, image in enumerate(player_turn_images):
            print(f"Image {a + idx + 1} / 50")
            try:
                img_aliniata, h = alignImages(image, board_template)
                cropped_image = img_aliniata[140:945, 140:945]

                patch_size = (int(cropped_image.shape[0] / 14), int(cropped_image.shape[1] / 14))

                preds = []
                for i in range(14):
                    for j in range(14):
                        if board[i][j] is None:
                            x1, y1 = i * patch_size[0], j * patch_size[1]
                            x2, y2 = x1 + patch_size[0], y1 + patch_size[1]
                            patch = cropped_image[x1:x2, y1:y2]

                            label, score = classify_patch(patch)
                            if label >= 0:
                                preds.append((i, j, label, score))

                preds.sort(key=lambda x: x[3], reverse=True)

                i, j, label, score = preds[0]  # best pred

                board[i][j] = label

                points += get_score(board, i, j)
                print(f"{points=}")

                txt_name = None
                if a + idx + 1 >= 10:
                    txt_name = a + idx + 1
                else:
                    txt_name = f"0{a + idx + 1}"

                with open(f"{path}/tmp_sol/{game_idx + 1}_{txt_name}.txt", "w") as f:
                    f.write(f"{i + 1}{int_to_dict[j + 1]}  {label}\n")
                    print(f"{i}|{j} {label=}-{score=:.2f}")

            except Exception as e:
                print(e)
            print("-----")

        with open(f"{path}/tmp_sol/{game_idx + 1}_scores.txt", "a") as g:
            if turn1.endswith("\n"):
                g.write(f"{turn1[:-1]} {points}\n")
            else:
                g.write(f"{turn1} {points}")
