required libraries:

    numpy==1.26.4 (latest version)
    opencv-contrib-python==4.9.0.80 (latest version)
    torch==2.3.1 (latest version) # https://pytorch.org/get-started/locally/
    pillow==10.3.0 (latest version)

To run the solution you need to run the task1_solution.py respectively task2_solution.py depending of the task

Inside the scripts you might need to modify two lines:

task1_solution.py
- line 110, 111 -> path to test dir and solution save dir

task1_solution.py
- line 87, 88 -> path to test dir and solution save dir
