kb([
    [neg(a), b],
    [c, f],
    [neg(c)],
    [neg(f), b],
    [neg(c), b]
]).

query([]).
