kb([
    [a, b],
    [neg(a), neg(b)],
    [c]
]).

query([]).
