kb([
    [neg(b), a],
    [neg(a), b, e],
    [a, neg(e)],
    [neg(a)],
    [e]
]).

query([]).
