kb([
    [neg(a), b],
    [c, d],
    [neg(d), b],
    [neg(b)],
    [neg(c), b],
    [e],
    [f, a, b, neg(f)]
]).

query([]).
