clauses([
    [toddler],
    [neg(toddler), child],
    [neg(child), neg(male), boy],
    [neg(infant), child],
    [neg(child), neg(female), girl],
    [female],
    [neg(girl)]
]).
