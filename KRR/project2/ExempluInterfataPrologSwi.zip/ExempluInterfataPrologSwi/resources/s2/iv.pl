clauses([
    [neg(b), a],
    [neg(a), b, e],
    [e],
    [a, neg(e)],
    [neg(a)]
]).
