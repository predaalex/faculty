clauses([
    [a, b],
    [neg(a), neg(b)],
    [neg(a), b],
    [a, neg(b)]
]).
