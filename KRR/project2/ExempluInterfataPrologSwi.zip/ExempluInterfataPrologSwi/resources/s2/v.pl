clauses([
    [neg(a), neg(e), b],
    [neg(d), e, neg(b)],
    [neg(e), f, neg(b)],
    [f, neg(a), e],
    [e, f, neg(b)]
]).
