clauses([
    [neg(a) , b],
    [c      , d],
    [neg(d) , b],
    [neg(c) , b],
    [neg(b)],
    [e],
    [f, a, b, neg(f)]
]).
