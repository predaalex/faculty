#%%
import warnings

import pandas as pd
import numpy as np
import sklearn
import nltk
import spacy
import re
import wandb
from datasets import load_dataset
from tqdm import tqdm
from sklearn.exceptions import ConvergenceWarning
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer

warnings.filterwarnings("ignore", category=ConvergenceWarning)
wandb.errors.term._show_warnings = False
#%%
wandb.login()
#%% md
# The dataset that i am using has two configurations:
# 
# | Name    | Train | Validation | Test |
# |---------|-------|------------|------|
# | Split   | 16000 | 2000       | 2000 |
# | Unsplit | 416809| n/a        | n/a  |
# 
# I will be using both configurations and test with a smaller corpus for training and then a bigger one.
#%%
splitted_ds = load_dataset("dair-ai/emotion", "split")
# unsplitted_ds = load_dataset("dair-ai/emotion", "unsplit")

# df_unsplit_train = unsplitted_ds['train'].to_pandas()
df_train = splitted_ds['train'].to_pandas()
df_test = splitted_ds['test'].to_pandas()
df_validation = splitted_ds['validation'].to_pandas()
#%% md
# # Data Fields
# The data fields are:
# 
# **text**: a string feature.|
# 
# **label**: a classification label, with possible values including: 
# 
# 0 -> sadness
# 
# 1 -> joy
# 
# 2 -> love
# 
# 3 -> anger
# 
# 4 -> fear
# 
# 5 -> surprise
#%%
df_train.head()
#%% md
# # The number of data for each label. It can be seen that the data is a little unbalanced in the splitted training dataset. Same story applies to unsplitted dataset
#%%
df_train['label'].value_counts()
#%%
# df_unsplit_train['label'].value_counts()
#%% md
# # SnowballStemmer:
# 
# - After processing the word through all these rules, the stemmer produces a stem—a simplified version of the word that represents its core meaning. This stem is not always a valid word in the language but is a useful representation for analysis purposes.
# - For example, “running” becomes “run,” “studies” becomes “studi,” and “better” becomes “better” (sometimes the word is already in its simplest form).
#%%
import gensim.downloader as api

list(api.info()['models'].keys())
#%%
ss = nltk.stem.snowball.SnowballStemmer("english")
sw = nltk.corpus.stopwords.words('english')
nlp = spacy.load('en_core_web_sm')  # english tokenizer trf -> accuracy | sm -> efficiency
word2vec = api.load("word2vec-google-news-300")  # Load the pretrained Word2Vec model
print("models imported!")
#%%
def text_preparetion(sentence, nlp):
    # 1. Lowercase everything
    sentence = sentence.lower()

    # 2. Remove all symbols other than a-z@#.
    sentence = re.sub(r"[^a-zăâîșț@# ]", "", sentence)

    # # Tokenize the preprocessed sentence
    tokenization = nlp(sentence)

    # 4. Remove stopwords and empty tokens and split sentence into words
    list_text_preprocessed = [
        word.text for word in tokenization if word.text not in sw and word.pos_ != "SPACE"
    ]
    
    return ' '.join(list_text_preprocessed)


def text_vectorization_word2vec(sentence, model):
    words = sentence.split()
    words_embeddings = [model[word] for word in words if word in model]
    
    # if there are no words in the word2vec
    if not words_embeddings:
        return np.zeros(model.vector_size)
    
    # Average the word vectors to get a single sentece represenation
    return np.mean(words_embeddings, axis=0)

def text_vectorization_word2vec_weighted(sentence, model, train_tfidf_dict):
    words = sentence.split()
    words_embeddings = []
    
    for word in words:
        weight = train_tfidf_dict.get(word, 1.0)
        if word in model:
            words_embeddings.append(weight * model[word])
    
    # if there are no words in the word2vec
    if not words_embeddings:
        return np.zeros(model.vector_size)
    
    # Average the word vectors to get a single sentece represenation
    return np.mean(words_embeddings, axis=0)

tqdm.pandas()

# Preprocessing
df_train['text'] = df_train['text'].progress_apply(lambda x: text_preparetion(x, nlp))
df_test['text'] = df_test['text'].progress_apply(lambda x: text_preparetion(x, nlp))
df_validation['text'] = df_validation['text'].progress_apply(lambda x: text_preparetion(x, nlp))
print("PREPROCESSING!")

# TF-IDF
vectorizer = TfidfVectorizer()
# vectorizer = CountVectorizer()
X_train_tfidf = vectorizer.fit_transform(df_train['text'])
train_tfidf_dict = dict(zip(vectorizer.get_feature_names_out(), vectorizer.idf_))
X_val_tfidf = vectorizer.transform(df_validation['text'])
X_test_tfidf = vectorizer.transform(df_test['text'])
print("TF-IDF!")

# word2vec
df_train['embeddings'] = df_train['text'].progress_apply(lambda x: text_vectorization_word2vec(x, word2vec))
df_test['embeddings'] = df_test['text'].progress_apply(lambda x: text_vectorization_word2vec(x, word2vec))
df_validation['embeddings'] = df_validation['text'].progress_apply(lambda x: text_vectorization_word2vec(x, word2vec))
print("WORD2VEC!")

# weighted word2vec
df_train['weighted_embeddings'] = df_train['text'].progress_apply(lambda x: text_vectorization_word2vec_weighted(x, word2vec, train_tfidf_dict))
df_test['weighted_embeddings'] = df_test['text'].progress_apply(lambda x: text_vectorization_word2vec_weighted(x, word2vec, train_tfidf_dict))
df_validation['weighted_embeddings'] = df_validation['text'].progress_apply(lambda x: text_vectorization_word2vec_weighted(x, word2vec, train_tfidf_dict))
print("WEIGHTED WORD2VEC!")
# df_unsplit_train['embeddings'] = df_unsplit_train['text'].progress_apply(lambda x: text_preparetion(x, word2vec))
#%%
# save preprocessed dataset
df_train.to_csv("./data/split_train.csv", index=False)
df_test.to_csv("./data/test.csv", index=False)
df_validation.to_csv("./data/validation.csv", index=False)
# df_unsplit_train.to_csv("./data/unsplit_train.csv", index=False)
#%%
df_train[:100]
#%%
X_train = df_train['embeddings'].to_numpy()
X_train = np.vstack(X_train)

Y_train = df_train['label']

X_val = df_validation['embeddings'].to_numpy()
X_val = np.vstack(X_val)
Y_val = df_validation['label']

X_test = df_test['embeddings'].to_numpy()
X_test = np.vstack(X_test)
Y_test = df_test['label']
#%% md
# # SVM
#%%
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV, StratifiedKFold

svm = SVC(verbose=1, probability=True)

param_grid = {
    'C': [0.1, 1, 10],
    'kernel': ['linear', 'poly', 'rbf', 'sigmoid']
}

# Use StratifiedKFold for cross-validation
kf = StratifiedKFold(n_splits=2)

# GridSearchCV to find the best parameters
grid_search = GridSearchCV(svm, param_grid, cv=kf, n_jobs=8, scoring="f1_weighted", verbose=1)
grid_search.fit(X_train, Y_train)

# Best parameters and best score
print("Best parameters:", grid_search.best_params_)
print("Best cross-validation score:", grid_search.best_score_)
#%% md
# # KNN
#%%
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV, StratifiedKFold

# Initialize the KNN classifier
knn = KNeighborsClassifier()

# Define the parameter grid for KNN
param_grid = {
    'n_neighbors': [3, 7, 11, 15, 19, 23, 31],  # Number of neighbors to use
    'weights': ['uniform', 'distance'],  # Weight function used in prediction
}

# Use StratifiedKFold for cross-validation
kf = StratifiedKFold(n_splits=2)

# GridSearchCV to find the best parameters
grid_search = GridSearchCV(knn, param_grid, cv=kf, n_jobs=8, scoring="f1_weighted", verbose=1)
grid_search.fit(X_train, Y_train)

# Best parameters and best score
print("Best parameters:", grid_search.best_params_)
print("Best cross-validation score:", grid_search.best_score_)

#%%
best_model = grid_search.best_estimator_
test_predictions = best_model.predict(X_test)
test_probas = best_model.predict_proba(X_test)
#%%
from sklearn.metrics import classification_report

report = classification_report(Y_test, test_predictions)
print(report)
#%%
run = wandb.init(project='Emotion', name="KNN-classification-embeddings")
#%%
labels = [0, 1, 2, 3, 4, 5]
labels
#%%
wandb.sklearn.plot_classifier(best_model,
                              X_train, X_test,
                              Y_train, Y_test,
                              test_predictions, test_probas,
                              labels,
                              is_binary=False,
                              model_name='SVM')
#%%
wandb.finish()